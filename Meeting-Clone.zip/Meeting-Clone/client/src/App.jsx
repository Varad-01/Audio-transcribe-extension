import React, { useState, useEffect } from "react";
import axios from "axios";

const API_URL = "http://localhost:3000";

function App() {
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(null);
  const [pdfLinks, setPdfLinks] = useState({});

  useEffect(() => {
    fetchFiles();
  }, []);

  const fetchFiles = async () => {
    try {
      const response = await axios.get(`${API_URL}/files`);
      setFiles(response.data);
    } catch (error) {
      console.error("Error fetching files:", error);
    }
  };

  const processFile = async (fileName) => {
    setLoading(fileName);
    try {
      const response = await axios.post(`${API_URL}/processTranscript`, { fileName });
      setPdfLinks((prev) => ({ ...prev, [fileName]: `${API_URL}${response.data.pdfPath}` }));
    } catch (error) {
      console.error("Error processing file:", error);
    }
    setLoading(null);
  };

  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h2>TranscripTonic Dashboard</h2>
      <table border="1" cellPadding="10" style={{ width: "100%", marginTop: "10px" }}>
        <thead>
          <tr>
            <th>File Name</th>
            <th>Actions</th>
            <th>PDF</th>
          </tr>
        </thead>
        <tbody>
          {files.length > 0 ? (
            files.map((file, index) => (
              <tr key={index}>
                <td>{file}</td>
                <td>
                  <button
                    onClick={() => processFile(file)}
                    disabled={loading === file}
                    style={{
                      backgroundColor: loading === file ? "gray" : "#4CAF50",
                      color: "white",
                      padding: "5px 10px",
                      border: "none",
                      cursor: "pointer"
                    }}
                  >
                    {loading === file ? "Processing..." : "Generate PDF"}
                  </button>
                </td>
                <td>
                  {pdfLinks[file] ? (
                    <a href={pdfLinks[file]} target="_blank" rel="noopener noreferrer">
                      Download PDF
                    </a>
                  ) : (
                    "Not Available"
                  )}
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="3">No TXT files found</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

export default App;
