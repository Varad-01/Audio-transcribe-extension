require("dotenv").config();
const express = require("express");
const fs = require("fs");
const path = require("path");
const cors = require("cors");
const PDFDocument = require("pdfkit");
const { GoogleGenerativeAI, SchemaType } = require("@google/generative-ai");

const app = express();
const port = 3000;
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

app.use(cors());
app.use(express.json());

const TRANSCRIPT_DIR = "C:/Users/Shrutika/Downloads/TranscripTonic";
const PDF_DIR = path.join(TRANSCRIPT_DIR, "summaries");

// Ensure the PDF directory exists
if (!fs.existsSync(PDF_DIR)) fs.mkdirSync(PDF_DIR);

// Structured response schema for Gemini AI
const schema = {
  type: SchemaType.OBJECT,
  properties: {
    title: { type: SchemaType.STRING, description: "Title of the summary" },
    description: { type: SchemaType.STRING, description: "Brief summary" },
    keyPoints: { type: SchemaType.ARRAY, items: { type: SchemaType.STRING } },
    conclusion: { type: SchemaType.STRING, description: "Final conclusion" }
  },
  required: ["title", "description", "keyPoints", "conclusion"]
};

// Get list of TXT files
app.get("/files", (req, res) => {
  fs.readdir(TRANSCRIPT_DIR, (err, files) => {
    if (err) return res.status(500).json({ error: "Failed to read directory" });
    const txtFiles = files.filter((file) => file.endsWith(".txt"));
    res.json(txtFiles);
  });
});

// Process and summarize a TXT file
app.post("/processTranscript", async (req, res) => {
  try {
    const { fileName } = req.body;
    const filePath = path.join(TRANSCRIPT_DIR, fileName);

    if (!fs.existsSync(filePath)) {
      return res.status(400).json({ error: "File not found" });
    }

    const transcriptText = fs.readFileSync(filePath, "utf8");

    const prompt = `Summarize this text in a structured format:

"${transcriptText}"

Include:
- Title
- Summary
- Key points (bullet list)
- Conclusion`;

    const model = genAI.getGenerativeModel({
      model: "gemini-1.5-pro",
      generationConfig: { responseMimeType: "application/json", responseSchema: schema }
    });

    const result = await model.generateContent(prompt);
    const structuredData = JSON.parse(result.response.text());

    const pdfFileName = `${fileName.replace(".txt", "")}_summary.pdf`;
    const pdfPath = path.join(PDF_DIR, pdfFileName);

    generatePDF(structuredData, pdfPath);

    res.json({ message: "PDF created successfully", pdfPath: `/summaries/${pdfFileName}` });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error processing transcript" });
  }
});

// Generate PDF file
const generatePDF = (data, filePath) => {
  const doc = new PDFDocument();
  const stream = fs.createWriteStream(filePath);
  doc.pipe(stream);

  doc.fontSize(20).text(data.title, { align: "center" });
  doc.moveDown();
  doc.fontSize(14).text("Summary:", { underline: true });
  doc.fontSize(12).text(data.description);
  doc.moveDown();

  doc.fontSize(14).text("Key Points:", { underline: true });
  data.keyPoints.forEach((point) => {
    doc.fontSize(12).text(`- ${point}`);
  });
  doc.moveDown();

  doc.fontSize(14).text("Conclusion:", { underline: true });
  doc.fontSize(12).text(data.conclusion);

  doc.end();
};

app.use("/summaries", express.static(PDF_DIR));

app.listen(port, () => console.log(`Server running on port ${port}`));
