// extension/background.js
chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    console.log(message.type);
    if (message.type === "new_meeting_started") {
      // Save current tab id so we know which tab to monitor for meeting close events
      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        const tabId = tabs[0].id;
        chrome.storage.local.set({ meetingTabId: tabId }, function () {
          console.log("Meeting tab id saved");
        });
      });
    }
    if (message.type === "download") {
      // Clear the meeting tab id and send transcript data to server
      chrome.storage.local.set({ meetingTabId: null }, function () {
        console.log("Meeting tab id cleared");
      });
      sendTranscriptToServer();
    }
    return true;
  });
  
  // If the meeting tab is closed, send transcript to server
  chrome.tabs.onRemoved.addListener(function (tabId) {
    chrome.storage.local.get(["meetingTabId"], function (data) {
      if (tabId === data.meetingTabId) {
        console.log("Successfully intercepted tab close");
        sendTranscriptToServer();
        chrome.storage.local.set({ meetingTabId: null }, function () {
          console.log("Meeting tab id cleared for next meeting");
        });
      }
    });
  });
  
  // Function to build transcript content and send it to the server
  function sendTranscriptToServer() {
    chrome.storage.local.get(
      [
        "userName",
        "transcript",
        "chatMessages",
        "meetingTitle",
        "meetingStartTimeStamp"
      ],
      function (result) {
        if (result.userName && result.transcript && result.chatMessages) {
          const fileName =
            result.meetingTitle && result.meetingStartTimeStamp
              ? `Transcript-${result.meetingTitle} at ${result.meetingStartTimeStamp}.txt`
              : `Transcript.txt`;
  
          const lines = [];
          result.transcript.forEach((entry) => {
            lines.push(`${entry.personName} (${entry.timeStamp})`);
            lines.push(entry.personTranscript);
            lines.push("");
          });
          lines.push("");
          lines.push("");
          if (result.chatMessages.length > 0) {
            lines.push("---------------");
            lines.push("CHAT MESSAGES");
            lines.push("---------------");
            result.chatMessages.forEach((entry) => {
              lines.push(`${entry.personName} (${entry.timeStamp})`);
              lines.push(entry.chatMessageText);
              lines.push("");
            });
            lines.push("");
            lines.push("");
          }
          lines.push("---------------");
          lines.push(
            "Transcript saved using TranscripTonic Chrome extension (https://chrome.google.com/webstore/detail/ciepnfnceimjehngolkijpnbappkkiag)"
          );
          lines.push("---------------");
  
          const textContent = lines.join("\n").replace(/You \(/g, result.userName + " (");
  
          // Send the transcript data to the server endpoint
          fetch("http://localhost:3000/processTranscript", {
            method: "POST",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              fileName: fileName,
              transcriptText: textContent
            })
          })
            .then((response) => response.json())
            .then((data) => {
              console.log("Server response:", data);
            })
            .catch((error) => {
              console.error("Error sending transcript to server:", error);
            });
        } else {
          console.log("No transcript found");
        }
      }
    );
  }
  